<?php
	$dbc = mysqli_connect('localhost', 'root', '', 'elvis_store')
		or die('Error connecting to MySQL server.');
?>