<html>

<head>
	<title></title>
</head>
	
<body>
	<h2></h2>


<?php
	include 'DBconnection.php';

	$email = $_POST['email'];

	$query = "DELETE FROM email_list WHERE email = '$email'";

	mysqli_query($dbc, $query)
	or die('Error querying de la databasoes.');

	Echo 'Customer removed:' . $email;

	mysqli_close($dbc);

?>

</body>

</html>