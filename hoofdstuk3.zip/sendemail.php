<html>

<head>
	<title></title>
</head>
	
<body>
	<h2></h2>


<?php
	include 'DBconnection.php';


  	$from = 'elmer@makemeelvis.com';
  	$subject = $_POST['subject'];
  	$text = $_POST['elvismail'];

  	$query = "SELECT * FROM email_list";
  	$result = mysqli_query($dbc, $query)
  		or die('Error querying le databaser.');

  	while ($row = mysqli_fetch_array($result)){
  		$to = $row['email'];
  		$first_name = $row['first_name'];
  		$last_name = $row['last_name'];
  		$msg = "Dear $first_name $last_name, \n$text";
  		// mail($to, $subject, $msg, 'From:' . $from);
  	}
  	  		echo 'Email sent to: ' . $to . '<br />';

  	mysqli_close($dbc);

?>

</body>

</html>