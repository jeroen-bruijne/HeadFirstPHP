<html>

<head>
	<title></title>
</head>
	
<body>
	<h2></h2>


<?php
	include 'DBconnection.php';

	$first_name = $_POST['firstname'];
	$last_name = $_POST['lastname'];
	$email = $_POST['email'];

	$query = "INSERT INTO email_list (first_name, last_name, email)" .
	"VALUES ('$first_name', '$last_name', '$email')";

	mysqli_query($dbc, $query)
	or die('Error querying database failed m8.');

	Echo 'Customer added.';

	mysqli_close($dbc);
?>

</body>

</html>